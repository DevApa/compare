﻿WINMERGE

WinMerge on Open Source vertailu- ja yhdistelytyökalu Windowsille. WinMerge vertailee kansioita ja tiedostoja, esittäen erot visuaalisessa tekstimuodossa, jota on helppo ymmärtää ja käsitellä. WinMergeä voidaan käyttää ulkoisena erottelu-/yhdistelytyökaluna tai itsenäisenä sovelluksena.

WinMergessä on monia hyödyllisiä tukiominaisuuksia, jotka tekevät vertailusta, synkronoinnista ja yhdistämisistä niin helppoja ja hyödyllisiä kuin mahdollista. Useat ohjelmointikielet ja muut tiedostomuodot ovat syntaksikorostettuja.

Uusin WinMerge versio ja tiedot ovat saatavilla osoitteessa https://winmerge.org/.

Pika-aloitus
============
Lisätietoja WinMergen perustoiminnoista saat klikkaamalla Ohje>WinMerge Ohje ja siirtymällä Pikakäynnistys-aiheisiin. Tai mene verkkoversioon https://manual.winmerge.org/Quick_start.html.

WinMerge Ohje
=============
WinMerge ohje on asennettu paikallisesti asennuksen yhteydessä Microsoft HTML help-tiedostona, WinMerge.chm. Avaa ohje valitsemalla Ohje>WinMerge Ohje tai paina F1 WinMerge-ikkunassa. Komentorivillä suorita WinMerge /? valinnalla.

Voit myös selata WinMerge ohjeen HTML-versiota sivuilla https://manual.winmerge.org/.

WinMerge tuki
=============
Kysymyksiä tai ehdotuksia WinMergestä? Hyvä paikka aloittaa on WinMerge yhteisön ilmoitustaulu https://forums.winmerge.org/. Kehittäjät lukevat ja vastaavat kysymyksiin molemmilla foorumeilla. Käytä avointa keskustelufoorumia yleisiin WinMerge-kysymyksiin, kuten kysymyksiä käytöstä. Käytä kehittäjien foorumia WinMergen tuotekehityskysymyksiin.

Viat ja ominaisuuspyynnöt
=========================
Jos ongelma ei ratkennut WinMerge-foorumeilla, tarkista projektin seuraajista: Siirry https://project.winmerge.org/ ja klikkaa linkkiä Trackers-valikosta ->Viat ja pyynnöt, jossa voit selata tai lähettää yksityiskohtia.

Jos lähetät vikailmoituksen, ilmoita WinMergen versionumero raportissasi. Voit luoda kokoonpanolokin valitsemalla Ohje->Kokoonpano. Liitä kokoonpanoloki vikailmoitukseen; siinä on paljon hyödyllistä tietoa sovelluskehittäjille.


- WinMerge-kehittäjät
