﻿WINMERGE

WinMerge hè un attrezzu di paragone è di fusione à fonte aperta per Windows.
WinMerge pò paragunà cartulari è schedarii è affissà e sfarenze in un furmatu
di testu visuale chì hè capicitoghju è faciule à manighjà. WinMerge pò esse
impiegatu, sia cum’è un attrezzu esternu di paragone o di fusione, sia cum’è
un’appiecazione autonoma.

WinMerge cuntene tante funzioni per rende più faciule u paragone, a
sincrunizazione è a fusione. Parechji linguaghji di prugrammazione è altri
furmati di schedariu anu a so sintassa sopralineata.

L’ultime versione è infurmazione di WinMerge sò dispunibule à l’indirizzu :
	https://winmerge.org/

Lanciu rapidu
=============
Per amparà cumu fà l’operazioni basichi dopu à l’installazione di WinMerge,
cliccu nant’à Aiutu > Aiutu WinMerge è navigate à u paragrafu di u lanciu
rapidu. Osinnò, impiegate a versione web à l’indirizzu :
	https://manual.winmerge.org/Quick_start.html

Aiutu WinMerge
============== 
L’aiutu di WinMerge hè installatu di lucale cum’è un schedariu d’aiutu HTML
Microsoft, WinMerge.chm, durante l’installazione de WinMerge. Per apre
l’aiutu, cliccu nant’à Aiutu > Aiutu WinMerge o appughjate nant’à u tastu F1
in a finestra di WinMerge. Nant’à a linea di cumanda, lanciate u schedariu
d’esecuzione WinMerge cù u cumutatore d’aiutu /?.

Pudete dinù sfuglià a versione HTML di l’aiutu di WinMerge à l’indirizzu :
	https://manual.winmerge.org/

Assistenza WinMerge
===================
Dumande o suggestioni apprupositu di WinMerge ? Un bellu locu per principià
hè u foru di chjachjerata di a cumunità WinMerge chì si trova à l’indirizzu
https://github.com/WinMerge/winmerge/discussions. Di manera regulare,
i sviluppatori leghjenu è rispondenu à e dumande nant’à stu foru.
Impiegate i fori di chjachjerata generale per i penseri nant’à WinMerge,
cum’è e dumande apprupositu di u so adopru. Impiegate u foru di
i sviluppatori per i penseri nant’à u sviluppu di WinMerge.

Riferimentu di prublemi è dumande di funzioni
=============================================
S’è un penseru ùn hè micca scioltu via u foru di chjachjerata di WinMerge,
verificate u ghjestiunariu di penseri di u prughjettu à l’indirizzu
https://github.com/WinMerge/winmerge/issues induve si pò cunsultà
l’articuli dighjà creati o mandà e vostre dumande.

S’è vo mandate un raportu di prublema, ci vole à indicà u numeru di
versione di WinMerge in u vostru raportu. Pudete ingenerà un ghjurnale
di cunfigurazione grazia à l’azzione Aiutu > Cunfigurazione. Ci vole à
aghjunghje stu ghjurnale à u vostru raportu di prublema perchè ci hè
parechje infurmazioni ghjuvevule per i sviluppatori.


- I sviluppatori di WinMerge
